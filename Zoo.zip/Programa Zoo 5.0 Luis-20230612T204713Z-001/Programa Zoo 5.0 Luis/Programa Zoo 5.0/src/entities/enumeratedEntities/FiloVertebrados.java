package entities.enumeratedEntities;

public enum FiloVertebrados {
	PEIXES, ANFÍBIOS, RÉPTEIS, AVES, MAMÍFEROS
}
