package entities.enumeratedEntities;

public enum FiloInvertebrados {
	PORÍFEROS, CNIDÁRIOS, PLATELMINTOS, NEMATELMINTOS, ANELÍDEOS, EQUINODERMOS, MOLUSCO, ARTRÓPEDES
}
