package entities.enumeratedEntities;

public enum Genero {
	Macho, Femêa, Hermafrodita
}