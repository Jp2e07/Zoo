package entities.enumeratedEntities;

public enum HabAlimentar {
    Carnívoro,
    Herbívoro,
    Onívoro
}